#ifndef _LIBRARY_H_

#define _LIBRARY_H_

int sum(const int num1, const int num2);
int sub(const int num1, const int num2);

int min(const int count, int *x);
int max(const int count, int *x);

void swap(int *x, int *y);

#endif