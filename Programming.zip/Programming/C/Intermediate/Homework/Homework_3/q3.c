int main(void)
{
int x[10];

// should only go to 9, change to i < 9
for (i = 0, i <= 10, i++)
{

// variables are case sensitive, 'I' should be 'i' instead and there needs to be a semi colon at the end of the line
x[i] = I * 10
}
}
// Not required but return 0; is nice to have when main function has return type int