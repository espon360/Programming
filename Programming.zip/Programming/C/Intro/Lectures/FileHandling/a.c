#include <stdio.h>
#include <stdlib.h>

void main()
{
    int grade[3] = {70, 40, 50};

    printf("%d", grade+0);
}