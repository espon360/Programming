#include <stdio.h>
int main(){

	int x, y

	return 0;
}
