#include <stdio.h>
int main(){
printf("Hello universe!\n");
return 0;
} 