#include <stdio.h>

int main(){
	int number, result; // declare integer

	scanf("%d", &number); // read that integer from the user

	result = number * 2; // caculate integer multiplied by 2

	printf("The result is: %d\n", result) // display result

	return 0;
}
