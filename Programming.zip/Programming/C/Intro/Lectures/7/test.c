#include <stdio.h>
#include <string.h>
int main(){
	
	char variables[5] = "Jason";
	printf("%s", variables);

	return 0;
}
