#include <stdio.h>

int main(){

	//declare an int variable
	int variable, result;

	//read integer
	scanf("%d", &variable);

	// compute the multiplication
	result = variable*2;

	// print result
	printf("The result is: %d.\n", result);


	return 0;
}
