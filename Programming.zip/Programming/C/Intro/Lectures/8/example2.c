#include <stdio.h>
#include <math.h>
int main(){

	int houseNum;
	double housePrice;

	// Enter housePrice
	scanf("%lf", &housePrice);
	printf("%.2lf", housePrice);
	// the ".2" prior to the datatype means you will
	// display up to two decimals


	return 0;
}
