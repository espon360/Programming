#include <stdio.h>
#include <math.h>
int main(){

	int p = 5, q = 5, r = 10;

	// Display if statement is true
	printf("%d == %d is %d\n", p, q, p == q);
	// Will read is 5 == 5 is 1 which means 5 = 5 is true.

	return 0;
}
