#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void main()
{
    // Get password length
    int length;
    printf("The following program will input generate a random password.\n\n");
    printf("To start, please enter the desired password length: ");
    scanf("%d", &length);

    // Set limits on what characters to use
    int number, letter, special;
    printf("")
}