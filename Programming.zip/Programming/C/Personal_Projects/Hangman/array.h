void array1;
void document;
void string;